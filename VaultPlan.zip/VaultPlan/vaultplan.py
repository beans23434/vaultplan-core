import typer
from commands import account, income, expense, goal, debit, balance, summary, note, ritual
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

app = typer.Typer(help="VaultPlan - Your personal finance command center")
console = Console()

# Add command modules
app.add_typer(account.app, name="create-account")
app.add_typer(account.app, name="link-wallet")
app.add_typer(income.app, name="add-income")
app.add_typer(expense.app, name="add-expense")
app.add_typer(goal.app, name="set-goal")
app.add_typer(goal.app, name="list-goals")
app.add_typer(debit.app, name="add-debit")
app.add_typer(debit.app, name="pay-debit")
app.add_typer(debit.app, name="list-debits")
app.add_typer(balance.app, name="balance")
app.add_typer(summary.app, name="summary")
app.add_typer(note.app, name="add-note")
app.add_typer(note.app, name="list-notes")
app.add_typer(ritual.app, name="ritual")

@app.command()
def help():
    """Show comprehensive help with examples for all commands."""
    help_text = """
    [bold cyan]VaultPlan - Personal Finance CLI[/bold cyan]
    
    [bold]Account Management:[/bold]
    • [green]create-account[/green] <name> [--type bank/wallet] [--balance 0] [--wallet 0x...]
      Example: vaultplan create-account Jeremy --type bank --balance 1000
    
    • [green]link-wallet[/green] <account> <wallet_address>
      Example: vaultplan link-wallet Jeremy 0xdeadbeef...
    
    [bold]Transactions:[/bold]
    • [green]add-income[/green] <amount> [--source "source"] [--account name] [--date YYYY-MM-DD]
      Example: vaultplan add-income 300 --source "warpy" --account Jeremy
    
    • [green]add-expense[/green] <amount> [--category "category"] [--description "desc"] 
      [--account name] [--metadata '["item1", "item2"]'] [--note "note"]
      Example: vaultplan add-expense '$4.97' --category food --description "lunch" 
      --account Jeremy --metadata '["Milk", "Bread"]' --note "Weekly groceries"
    
    [bold]Goals & Debits:[/bold]
    • [green]set-goal[/green] <title> <target> <account> [--deadline YYYY-MM-DD] [--note "note"]
      Example: vaultplan set-goal "New Laptop" 1000 Jeremy --deadline "2024-12-31"
    
    • [green]list-goals[/green] [--account name] [--status active/completed]
      Example: vaultplan list-goals --account Jeremy --status active
    
    • [green]add-debit[/green] <label> <amount> <account> [--due-date YYYY-MM-DD] [--note "note"]
      Example: vaultplan add-debit "Rent" 800 Jeremy --due-date "2024-04-01"
    
    • [green]pay-debit[/green] <label> <amount> [--account name]
      Example: vaultplan pay-debit "Rent" 400 --account Jeremy
    
    • [green]list-debits[/green] [--account name] [--status pending/paid]
      Example: vaultplan list-debits --account Jeremy --status pending
    
    [bold]Reports & Notes:[/bold]
    • [green]balance[/green] [--account name] [--days 7]
      Example: vaultplan balance --account Jeremy --days 30
    
    • [green]summary[/green] [--account name] [--days 30]
      Example: vaultplan summary --account Jeremy --days 30
    
    • [green]add-note[/green] <mood> <note> [--account name] [--tags '["tag1", "tag2"]']
      Example: vaultplan add-note 8 "Feeling productive!" --account Jeremy 
      --tags '["work", "productive"]'
    
    • [green]list-notes[/green] [--account name] [--days 7]
      Example: vaultplan list-notes --account Jeremy --days 7
    
    [bold]Common Options:[/bold]
    • [yellow]--account[/yellow]: Filter by account name
    • [yellow]--days[/yellow]: Number of days to look back
    • [yellow]--note[/yellow]: Additional context or description
    • [yellow]--metadata[/yellow]: JSON array of items/tags
    
    [bold]Tips:[/bold]
    • Use quotes for text with spaces
    • Use $ for amounts (e.g., '$4.97')
    • Use JSON arrays for metadata/tags
    • All dates in YYYY-MM-DD format
    """
    
    console.print(Panel(help_text, title="VaultPlan Help", border_style="cyan"))
    
    # Show command groups
    table = Table(title="Command Groups")
    table.add_column("Group", style="cyan")
    table.add_column("Commands", style="green")
    
    table.add_row(
        "Account",
        "create-account, link-wallet"
    )
    table.add_row(
        "Transactions",
        "add-income, add-expense"
    )
    table.add_row(
        "Goals",
        "set-goal, list-goals"
    )
    table.add_row(
        "Debits",
        "add-debit, pay-debit, list-debits"
    )
    table.add_row(
        "Reports",
        "balance, summary"
    )
    table.add_row(
        "Notes",
        "add-note, list-notes"
    )
    
    console.print(table)

if __name__ == "__main__":
    app() 