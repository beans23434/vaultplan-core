from pathlib import Path

def ensure_data_dir():
    data_dir = Path(__file__).parent.parent / "data"
    data_dir.mkdir(exist_ok=True) 