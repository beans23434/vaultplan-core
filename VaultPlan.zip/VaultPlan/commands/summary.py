import typer
from pathlib import Path
import sqlite3
from datetime import datetime, timedelta
from utils.helpers import ensure_data_dir
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

app = typer.Typer()
console = Console()

def get_db():
    ensure_data_dir()
    db_path = Path(__file__).parent.parent / "data" / "vaultplan.db"
    conn = sqlite3.connect(db_path)
    return conn

@app.command()
def show_summary(
    account: str = typer.Option(None, help="Specific account to summarize"),
    days: int = typer.Option(30, help="Summary period in days")
):
    """Show a quick dashboard of financial progress."""
    conn = get_db()
    c = conn.cursor()
    
    # Get date range
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    
    # Get account balances
    if account:
        c.execute("SELECT name, type, balance FROM accounts WHERE name = ?", (account,))
    else:
        c.execute("SELECT name, type, balance FROM accounts")
    
    accounts = c.fetchall()
    total_balance = sum(acc[2] for acc in accounts)
    
    # Get income/expense totals
    if account:
        c.execute("""
            SELECT 
                COALESCE(SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END), 0) as income,
                COALESCE(SUM(CASE WHEN amount < 0 THEN ABS(amount) ELSE 0 END), 0) as expenses
            FROM (
                SELECT amount FROM income WHERE account = ? AND date >= ?
                UNION ALL
                SELECT -amount FROM expenses WHERE account = ? AND date >= ?
            )
        """, (account, start_date.strftime("%Y-%m-%d"), account, start_date.strftime("%Y-%m-%d")))
    else:
        c.execute("""
            SELECT 
                COALESCE(SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END), 0) as income,
                COALESCE(SUM(CASE WHEN amount < 0 THEN ABS(amount) ELSE 0 END), 0) as expenses
            FROM (
                SELECT amount FROM income WHERE date >= ?
                UNION ALL
                SELECT -amount FROM expenses WHERE date >= ?
            )
        """, (start_date.strftime("%Y-%m-%d"), start_date.strftime("%Y-%m-%d")))
    
    income, expenses = c.fetchone()
    net = income - expenses
    
    # Get active goals progress
    if account:
        c.execute("""
            SELECT COUNT(*), 
                   COALESCE(SUM(current), 0),
                   COALESCE(SUM(target), 0)
            FROM goals 
            WHERE account = ? AND status = 'active'
        """, (account,))
    else:
        c.execute("""
            SELECT COUNT(*), 
                   COALESCE(SUM(current), 0),
                   COALESCE(SUM(target), 0)
            FROM goals 
            WHERE status = 'active'
        """)
    
    goal_count, goal_current, goal_target = c.fetchone()
    goal_progress = (goal_current / goal_target * 100) if goal_target > 0 else 0
    
    # Get pending debits
    if account:
        c.execute("""
            SELECT COUNT(*), 
                   COALESCE(SUM(amount - paid), 0)
            FROM debits 
            WHERE account = ? AND status = 'pending'
        """, (account,))
    else:
        c.execute("""
            SELECT COUNT(*), 
                   COALESCE(SUM(amount - paid), 0)
            FROM debits 
            WHERE status = 'pending'
        """)
    
    debit_count, debit_remaining = c.fetchone()
    
    # Create summary panel
    summary = f"""
    [bold]Total Balance:[/bold] ${total_balance:.2f}
    
    [bold]Last {days} Days:[/bold]
    Income:   ${income:.2f}
    Expenses: ${expenses:.2f}
    Net:      ${net:.2f}
    
    [bold]Goals:[/bold]
    Active: {goal_count}
    Progress: {goal_progress:.1f}%
    
    [bold]Pending Debits:[/bold]
    Count: {debit_count}
    Remaining: ${debit_remaining:.2f}
    """
    
    console.print(Panel(summary, title="Financial Summary", border_style="cyan"))
    
    # Show recent activity
    activity_table = Table(title=f"Recent Activity (Last {days} days)")
    activity_table.add_column("Date", style="cyan")
    activity_table.add_column("Type", style="magenta")
    activity_table.add_column("Amount", style="green")
    activity_table.add_column("Description", style="yellow")
    
    # Get recent transactions
    if account:
        c.execute("""
            SELECT date, amount, 'Income' as type, source as desc
            FROM income 
            WHERE account = ? AND date >= ?
            UNION ALL
            SELECT date, -amount, 'Expense' as type, 
                   category || ': ' || description as desc
            FROM expenses 
            WHERE account = ? AND date >= ?
            ORDER BY date DESC
            LIMIT 5
        """, (account, start_date.strftime("%Y-%m-%d"), 
              account, start_date.strftime("%Y-%m-%d")))
    else:
        c.execute("""
            SELECT date, amount, 'Income' as type, source as desc
            FROM income 
            WHERE date >= ?
            UNION ALL
            SELECT date, -amount, 'Expense' as type, 
                   category || ': ' || description as desc
            FROM expenses 
            WHERE date >= ?
            ORDER BY date DESC
            LIMIT 5
        """, (start_date.strftime("%Y-%m-%d"), 
              start_date.strftime("%Y-%m-%d")))
    
    for row in c.fetchall():
        date, amount, type_, desc = row
        activity_table.add_row(
            date,
            type_,
            f"${abs(amount):.2f}",
            desc
        )
    
    console.print(activity_table)
    conn.close() 