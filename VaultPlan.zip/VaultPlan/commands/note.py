import typer
from pathlib import Path
import sqlite3
from datetime import datetime, timedelta
from utils.helpers import ensure_data_dir
from rich.console import Console
from rich.panel import Panel

app = typer.Typer()
console = Console()

def get_db():
    ensure_data_dir()
    db_path = Path(__file__).parent.parent / "data" / "vaultplan.db"
    conn = sqlite3.connect(db_path)
    return conn

@app.command()
def add_note(
    mood: int = typer.Argument(..., help="Mood rating (1-10)"),
    note: str = typer.Argument(..., help="Note content"),
    account: str = typer.Option(None, help="Related account (optional)"),
    tags: str = typer.Option("[]", help="JSON array of tags [tag1, tag2, ...]")
):
    """Log mental/emotional status with mood rating and note."""
    if not 1 <= mood <= 10:
        typer.echo("❌ Mood rating must be between 1 and 10")
        return
    
    conn = get_db()
    c = conn.cursor()
    
    # Create notes table
    c.execute("""
        CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mood INTEGER,
            note TEXT,
            account TEXT,
            tags TEXT,
            created_at TEXT
        )
    """)
    
    # Insert note
    created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    c.execute(
        """INSERT INTO notes 
           (mood, note, account, tags, created_at) 
           VALUES (?, ?, ?, ?, ?)""",
        (mood, note, account, tags, created_at)
    )
    
    conn.commit()
    conn.close()
    
    # Format output
    account_str = f" (Account: {account})" if account else ""
    typer.echo(f"📝 Note logged{account_str}")
    typer.echo(f"Mood: {'😊' * mood} ({mood}/10)")

@app.command()
def list_notes(
    account: str = typer.Option(None, help="Filter by account"),
    days: int = typer.Option(7, help="Show notes from last N days")
):
    """List recent notes with mood ratings."""
    conn = get_db()
    c = conn.cursor()
    
    # Get date range
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    
    # Get notes
    if account:
        c.execute("""
            SELECT mood, note, account, tags, created_at 
            FROM notes 
            WHERE account = ? AND created_at >= ?
            ORDER BY created_at DESC
        """, (account, start_date.strftime("%Y-%m-%d")))
    else:
        c.execute("""
            SELECT mood, note, account, tags, created_at 
            FROM notes 
            WHERE created_at >= ?
            ORDER BY created_at DESC
        """, (start_date.strftime("%Y-%m-%d"),))
    
    notes = c.fetchall()
    
    if not notes:
        typer.echo("No notes found.")
        return
    
    for note in notes:
        mood, content, account, tags, created_at = note
        
        # Create note panel
        note_panel = f"""
        [bold]Mood:[/bold] {'😊' * mood} ({mood}/10)
        [bold]Time:[/bold] {created_at}
        [bold]Account:[/bold] {account or '—'}
        [bold]Tags:[/bold] {tags}
        
        {content}
        """
        
        console.print(Panel(note_panel, border_style="cyan"))
    
    conn.close() 