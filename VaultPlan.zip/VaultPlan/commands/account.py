import typer
from pathlib import Path
import sqlite3
from utils.helpers import ensure_data_dir

app = typer.Typer()

def get_db():
    ensure_data_dir()
    db_path = Path(__file__).parent.parent / "data" / "vaultplan.db"
    conn = sqlite3.connect(db_path)
    return conn

@app.command()
def create_account(
    name: str = typer.Argument(..., help="Account name"),
    type: str = typer.Option("bank", help="Account type: bank or wallet"),
    balance: float = typer.Option(0.0, help="Initial balance"),
    wallet: str = typer.Option(None, help="Optional ETH wallet address")
):
    """Set up a local or wallet-linked financial identity."""
    conn = get_db()
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            type TEXT,
            balance REAL,
            wallet TEXT
        )
    """)
    c.execute(
        "INSERT INTO accounts (name, type, balance, wallet) VALUES (?, ?, ?, ?)",
        (name, type, balance, wallet)
    )
    conn.commit()
    conn.close()
    typer.echo(f"✅ Account '{name}' created (type: {type}, balance: {balance}, wallet: {wallet})")

@app.command()
def link_wallet(
    account: str = typer.Argument(..., help="Account name"),
    wallet: str = typer.Argument(..., help="Wallet address")
):
    """Link a Web3 wallet address to an existing account."""
    conn = get_db()
    c = conn.cursor()
    c.execute(
        "UPDATE accounts SET wallet = ? WHERE name = ?",
        (wallet, account)
    )
    conn.commit()
    conn.close()
    typer.echo(f"🔗 Linked wallet {wallet} to account '{account}'") 