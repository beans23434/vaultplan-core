import typer
from pathlib import Path
import sqlite3
from datetime import datetime
from utils.helpers import ensure_data_dir
from rich.console import Console

app = typer.Typer()
console = Console()

def get_db():
    ensure_data_dir()
    db_path = Path(__file__).parent.parent / "data" / "vaultplan.db"
    conn = sqlite3.connect(db_path)
    return conn

@app.command()
def add_debit(
    label: str = typer.Argument(..., help="Debit label/name"),
    amount: float = typer.Argument(..., help="Debit amount"),
    account: str = typer.Argument(..., help="Account name"),
    due_date: str = typer.Option(None, help="Due date (YYYY-MM-DD)"),
    note: str = typer.Option("", help="Additional note about the debit")
):
    """Add a new debit to track."""
    conn = get_db()
    c = conn.cursor()
    
    # Create debits table
    c.execute("""
        CREATE TABLE IF NOT EXISTS debits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            label TEXT,
            amount REAL,
            paid REAL DEFAULT 0,
            account TEXT,
            due_date TEXT,
            note TEXT,
            created_at TEXT,
            status TEXT DEFAULT 'pending'
        )
    """)
    
    # Insert debit
    created_at = datetime.now().strftime("%Y-%m-%d")
    c.execute(
        """INSERT INTO debits 
           (label, amount, account, due_date, note, created_at) 
           VALUES (?, ?, ?, ?, ?, ?)""",
        (label, amount, account, due_date, note, created_at)
    )
    
    conn.commit()
    conn.close()
    
    # Format output
    due_str = f" (Due: {due_date})" if due_date else ""
    note_str = f"\n📝 Note: {note}" if note else ""
    
    typer.echo(f"💳 Debit added: {label} (${amount:.2f}){due_str}{note_str}")

@app.command()
def pay_debit(
    label: str = typer.Argument(..., help="Debit label to pay"),
    amount: float = typer.Argument(..., help="Payment amount"),
    account: str = typer.Option(..., help="Account to pay from")
):
    """Pay off a tracked debit."""
    conn = get_db()
    c = conn.cursor()
    
    # Get debit info
    c.execute("""
        SELECT id, amount, paid, status 
        FROM debits 
        WHERE label = ? AND account = ?
    """, (label, account))
    
    debit = c.fetchone()
    if not debit:
        typer.echo(f"❌ Debit '{label}' not found for account '{account}'")
        return
    
    debit_id, total_amount, paid_amount, status = debit
    
    if status == 'paid':
        typer.echo(f"❌ Debit '{label}' is already paid")
        return
    
    # Update debit
    new_paid = paid_amount + amount
    new_status = 'paid' if new_paid >= total_amount else 'pending'
    
    c.execute("""
        UPDATE debits 
        SET paid = ?, status = ? 
        WHERE id = ?
    """, (new_paid, new_status, debit_id))
    
    # Update account balance
    c.execute("""
        UPDATE accounts 
        SET balance = balance - ? 
        WHERE name = ?
    """, (amount, account))
    
    conn.commit()
    conn.close()
    
    # Format output
    remaining = total_amount - new_paid
    if remaining > 0:
        typer.echo(f"💸 Paid ${amount:.2f} towards '{label}'. ${remaining:.2f} remaining.")
    else:
        typer.echo(f"✅ Fully paid '{label}'! (${total_amount:.2f})")

@app.command()
def list_debits(
    account: str = typer.Option(None, help="Filter by account"),
    status: str = typer.Option("pending", help="Filter by status (pending/paid)")
):
    """List all debits with payment status."""
    conn = get_db()
    c = conn.cursor()
    
    # Get debits
    if account:
        c.execute("""
            SELECT label, amount, paid, due_date, status 
            FROM debits 
            WHERE account = ? AND status = ?
            ORDER BY due_date ASC
        """, (account, status))
    else:
        c.execute("""
            SELECT label, amount, paid, due_date, status 
            FROM debits 
            WHERE status = ?
            ORDER BY due_date ASC
        """, (status,))
    
    debits = c.fetchall()
    
    if not debits:
        typer.echo("No debits found.")
        return
    
    for debit in debits:
        label, amount, paid, due_date, status = debit
        remaining = amount - paid
        
        console.print(f"\n[bold cyan]{label}[/bold cyan]")
        console.print(f"Total: ${amount:.2f}")
        console.print(f"Paid: ${paid:.2f}")
        console.print(f"Remaining: ${remaining:.2f}")
        if due_date:
            console.print(f"Due: {due_date}")
        console.print(f"Status: {status}\n")
    
    conn.close() 