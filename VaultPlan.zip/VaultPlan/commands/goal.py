import typer
from pathlib import Path
import sqlite3
from datetime import datetime
from utils.helpers import ensure_data_dir
from rich.console import Console
from rich.progress import Progress

app = typer.Typer()
console = Console()

def get_db():
    ensure_data_dir()
    db_path = Path(__file__).parent.parent / "data" / "vaultplan.db"
    conn = sqlite3.connect(db_path)
    return conn

@app.command()
def set_goal(
    title: str = typer.Argument(..., help="Goal title"),
    target: float = typer.Argument(..., help="Target amount"),
    account: str = typer.Argument(..., help="Account name"),
    deadline: str = typer.Option(None, help="Deadline (YYYY-MM-DD)"),
    note: str = typer.Option("", help="Additional note about the goal")
):
    """Create a financial goal with target amount and deadline."""
    conn = get_db()
    c = conn.cursor()
    
    # Create goals table
    c.execute("""
        CREATE TABLE IF NOT EXISTS goals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            target REAL,
            current REAL DEFAULT 0,
            account TEXT,
            deadline TEXT,
            note TEXT,
            created_at TEXT,
            status TEXT DEFAULT 'active'
        )
    """)
    
    # Insert goal
    created_at = datetime.now().strftime("%Y-%m-%d")
    c.execute(
        """INSERT INTO goals 
           (title, target, account, deadline, note, created_at) 
           VALUES (?, ?, ?, ?, ?, ?)""",
        (title, target, account, deadline, note, created_at)
    )
    
    conn.commit()
    conn.close()
    
    # Format output
    deadline_str = f" by {deadline}" if deadline else ""
    note_str = f"\n📝 Note: {note}" if note else ""
    
    typer.echo(f"🎯 Goal set: {title} (${target:.2f}){deadline_str}{note_str}")

@app.command()
def list_goals(
    account: str = typer.Option(None, help="Filter by account"),
    status: str = typer.Option("active", help="Filter by status (active/completed)")
):
    """List all goals with progress."""
    conn = get_db()
    c = conn.cursor()
    
    # Get goals
    if account:
        c.execute("""
            SELECT title, target, current, account, deadline, status 
            FROM goals 
            WHERE account = ? AND status = ?
            ORDER BY created_at DESC
        """, (account, status))
    else:
        c.execute("""
            SELECT title, target, current, account, deadline, status 
            FROM goals 
            WHERE status = ?
            ORDER BY created_at DESC
        """, (status,))
    
    goals = c.fetchall()
    
    if not goals:
        typer.echo("No goals found.")
        return
    
    for goal in goals:
        title, target, current, account, deadline, status = goal
        progress = (current / target) * 100 if target > 0 else 0
        
        console.print(f"\n[bold cyan]{title}[/bold cyan]")
        console.print(f"Account: {account}")
        console.print(f"Target: ${target:.2f}")
        console.print(f"Current: ${current:.2f}")
        if deadline:
            console.print(f"Deadline: {deadline}")
        
        with Progress() as progress_bar:
            task = progress_bar.add_task("[green]Progress", total=100)
            progress_bar.update(task, completed=progress)
        
        console.print(f"Status: {status}\n")
    
    conn.close() 