import typer
from pathlib import Path
import sqlite3
from datetime import datetime, timedelta
from utils.helpers import ensure_data_dir
from rich.console import Console
from rich.table import Table

app = typer.Typer()
console = Console()

def get_db():
    ensure_data_dir()
    db_path = Path(__file__).parent.parent / "data" / "vaultplan.db"
    conn = sqlite3.connect(db_path)
    return conn

@app.command()
def show_balance(
    account: str = typer.Option(None, help="Specific account to check (default: all)"),
    days: int = typer.Option(7, help="Show activity for last N days")
):
    """Show account balances and recent activity."""
    conn = get_db()
    c = conn.cursor()
    
    # Get account balances
    if account:
        c.execute("SELECT name, type, balance, wallet FROM accounts WHERE name = ?", (account,))
    else:
        c.execute("SELECT name, type, balance, wallet FROM accounts")
    
    accounts = c.fetchall()
    
    # Create balance table
    balance_table = Table(title="Account Balances")
    balance_table.add_column("Account", style="cyan")
    balance_table.add_column("Type", style="magenta")
    balance_table.add_column("Balance", style="green")
    balance_table.add_column("Wallet", style="yellow")
    
    for acc in accounts:
        name, type_, balance, wallet = acc
        balance_table.add_row(
            name,
            type_,
            f"${balance:.2f}",
            wallet or "—"
        )
    
    console.print(balance_table)
    
    # Get recent activity
    since_date = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    
    activity_table = Table(title=f"Recent Activity (Last {days} days)")
    activity_table.add_column("Date", style="cyan")
    activity_table.add_column("Type", style="magenta")
    activity_table.add_column("Amount", style="green")
    activity_table.add_column("Description", style="yellow")
    activity_table.add_column("Account", style="blue")
    
    # Get expenses
    if account:
        c.execute("""
            SELECT date, amount, category, description, account 
            FROM expenses 
            WHERE account = ? AND date >= ?
            ORDER BY date DESC
        """, (account, since_date))
    else:
        c.execute("""
            SELECT date, amount, category, description, account 
            FROM expenses 
            WHERE date >= ?
            ORDER BY date DESC
        """, (since_date,))
    
    for exp in c.fetchall():
        date, amount, category, desc, acc = exp
        activity_table.add_row(
            date,
            "Expense",
            f"-${amount:.2f}",
            f"{category}: {desc}",
            acc
        )
    
    # Get income
    if account:
        c.execute("""
            SELECT date, amount, source, account 
            FROM income 
            WHERE account = ? AND date >= ?
            ORDER BY date DESC
        """, (account, since_date))
    else:
        c.execute("""
            SELECT date, amount, source, account 
            FROM income 
            WHERE date >= ?
            ORDER BY date DESC
        """, (since_date,))
    
    for inc in c.fetchall():
        date, amount, source, acc = inc
        activity_table.add_row(
            date,
            "Income",
            f"+${amount:.2f}",
            source,
            acc
        )
    
    console.print(activity_table)
    conn.close() 