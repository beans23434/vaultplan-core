# VaultPlan

Personal finance CLI for accounts, income, and more.

## Setup

```bash
pip install -r requirements.txt
```

## Usage

```bash
python vaultplan.py create-account jeremy --type bank --balance 0
python vaultplan.py add-income 300 --source "warpy" --account jeremy
```

## Folder Structure

- `vaultplan.py` — CLI entry point
- `commands/` — Command modules
- `data/` — SQLite DB
- `utils/` — Helpers 